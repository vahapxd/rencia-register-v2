# Rencia Tarafından "Bubbles" Sunucusu için Kodlanmıştır 
# KOPYALAYANIN ANASINI GÖTTEN ///
